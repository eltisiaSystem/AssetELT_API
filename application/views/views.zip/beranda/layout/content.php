<?php 
  
// Content berfungsi untuk meload view / tampilan secara dinamis
if ($content) {
	$this->load->view($content); //load_view
}