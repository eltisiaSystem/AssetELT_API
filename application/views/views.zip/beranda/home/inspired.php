<div class="container" data-animate="fadeInUpBig">
    <div class="col-md-12">
        <div class="box slideshow">
            <h3>Get Inspired</h3>
            <p class="lead">Get the inspiration from our world class designers</p>
            <div id="get-inspired" class="owl-carousel owl-theme">
                <div class="item">
                    <a href="#">
                        <img src="img/getinspired1.jpg" alt="Get inspired" class="img-responsive">
                    </a>
                </div>
                <div class="item">
                    <a href="#">
                        <img src="img/getinspired2.jpg" alt="Get inspired" class="img-responsive">
                    </a>
                </div>
                <div class="item">
                    <a href="#">
                        <img src="img/getinspired3.jpg" alt="Get inspired" class="img-responsive">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>