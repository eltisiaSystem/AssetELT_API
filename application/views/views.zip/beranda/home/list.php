<?php 

// wrapper berfungsi untuk menggabungkan file template atau layout yang telah dipisah kedalam beberapa file
include('slider.php');
include('hotitem.php');
// include('inspired.php');
// include('testimoni.php');