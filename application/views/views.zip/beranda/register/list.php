<?php 

// wrapper berfungsi untuk menggabungkan file template atau layout yang telah dipisah kedalam beberapa file
include('filelocation.php');
include('registrationform.php');
// include('loginform.php');