<?php 

// wrapper berfungsi untuk menggabungkan file template atau layout yang telah dipisah kedalam beberapa file
require_once('head.php');
require_once('topbar.php');
require_once('header.php');
require_once('content.php');
// require_once('summary.php');
require_once('footer.php');