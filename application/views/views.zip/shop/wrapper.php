<?php 

// wrapper berfungsi untuk menggabungkan file template atau layout yang telah dipisah kedalam beberapa file
include('kategori_view.php');
include('produk.php');